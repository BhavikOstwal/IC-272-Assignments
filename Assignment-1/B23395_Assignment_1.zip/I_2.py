import pandas as pd

landslide = pd.read_csv("landslide_data_original.csv")

landslide_new = landslide.drop(labels=["dates", "stationid"], axis=1)
landslide_new = landslide_new[:len(landslide_new.columns)]
landslide_new.index = landslide_new.columns

def Pearson(i,j):
    attr1 = landslide.iloc[:,i].to_numpy()
    attr2 = landslide.iloc[:,j].to_numpy()
    mean1 = attr1.mean()
    mean2 = attr2.mean()
    if (i==j): return 1

    else: return sum((attr1 - mean1)*(attr2-mean2))/((sum((attr1-mean1)**2) * sum((attr2-mean2)**2))**0.5)

for i in range(len(landslide_new.columns)):
    for j in range(len(landslide_new.columns)):
        landslide_new.iloc[i,j] = Pearson(i+2,j+2)

print(landslide_new)

print()
print("List of redundand attribute with respect to \"lightavg\":", 
      [i for i in landslide_new[landslide_new['lightavg']>0.6].index if i!='lightavg'])

