import numpy as np
import matplotlib.pyplot as plt


vector1 = np.array([ 0.36256148, -0.06789732,  0.85726975,  0.35920426])
vector2 = np.array([-0.71025936, -0.66565722,  0.20451144,  0.10299118])

vector1_2D = vector1[:2]
vector2_2D = vector2[:2]

fig, ax = plt.subplots()


ax.quiver(0, 0, vector1_2D[0], vector1_2D[1], angles='xy', scale_units='xy', scale=1, color='r', label='Vector 1')
ax.quiver(0, 0, vector2_2D[0], vector2_2D[1], angles='xy', scale_units='xy', scale=1, color='b', label='Vector 2')


ax.set_xlim(-10, 10)
ax.set_ylim(-10, 10)
ax.set_xlabel('X axis')
ax.set_ylabel('Y axis')
ax.grid(True)
ax.legend()

plt.title('Projection of 4D Vectors onto the X-Y Plane')
plt.show()
